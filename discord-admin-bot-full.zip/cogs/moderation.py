import re
import discord
from discord import app_commands
from discord.ext import commands
from db import get_guild_settings

INVITE_RE = re.compile(r"(?:discord\.gg/|discord\.com/invite/)[a-zA-Z0-9]+", re.I)

def parse_duration(s: str) -> int:
    total = 0
    num = ""
    units = {"d":86400, "h":3600, "m":60, "s":1}
    for ch in s:
        if ch.isdigit():
            num += ch
        else:
            if num == "": continue
            unit = units.get(ch.lower())
            if unit:
                total += int(num) * unit
            num = ""
    if num:
        total += int(num)
    return total

class Moderation(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    group = app_commands.Group(name="mod", description="Moderation tools")

    @group.command(name="ban", description="Ban a member")
    @app_commands.default_permissions(ban_members=True)
    async def ban(self, interaction: discord.Interaction, user: discord.User, reason: str | None = None, delete_message_days: int = 0):
        await interaction.guild.ban(user, reason=reason, delete_message_seconds=delete_message_days*86400)
        await interaction.response.send_message(f"🔨 Banned {user.mention}. Reason: {reason or 'n/a'}", ephemeral=True)

    @group.command(name="unban", description="Unban a user by ID")
    @app_commands.default_permissions(ban_members=True)
    async def unban(self, interaction: discord.Interaction, user_id: str):
        user = await self.bot.fetch_user(int(user_id))
        await interaction.guild.unban(user)
        await interaction.response.send_message(f"✅ Unbanned {user}", ephemeral=True)

    @group.command(name="kick", description="Kick a member")
    @app_commands.default_permissions(kick_members=True)
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str | None = None):
        await member.kick(reason=reason)
        await interaction.response.send_message(f"👢 Kicked {member.mention}.", ephemeral=True)

    @group.command(name="mute", description="Timeout (mute) a member. Duration examples: 10m, 1h, 1d")
    @app_commands.default_permissions(moderate_members=True)
    async def mute(self, interaction: discord.Interaction, member: discord.Member, duration: str | None = None, reason: str | None = None):
        if duration:
            seconds = parse_duration(duration)
            until = discord.utils.utcnow() + discord.timedelta(seconds=seconds)
            await member.timeout(until, reason=reason)
            await interaction.response.send_message(f"🔇 Timed out {member.mention} for {duration}.", ephemeral=True)
        else:
            await member.timeout(discord.utils.utcnow() + discord.timedelta(days=28), reason=reason)
            await interaction.response.send_message(f"🔇 Timed out {member.mention} indefinitely (28 days).", ephemeral=True)

    @group.command(name="unmute", description="Remove timeout")
    @app_commands.default_permissions(moderate_members=True)
    async def unmute(self, interaction: discord.Interaction, member: discord.Member):
        await member.timeout(None)
        await interaction.response.send_message(f"⏱️ Removed timeout for {member.mention}.", ephemeral=True)

    @group.command(name="tempmute", description="Temporarily mute a member for given duration (e.g., 10m,1h)")
    @app_commands.default_permissions(moderate_members=True)
    async def tempmute(self, interaction: discord.Interaction, member: discord.Member, duration: str, reason: str | None = None):
        seconds = parse_duration(duration)
        if seconds <= 0:
            await interaction.response.send_message("⚠️ Invalid duration.", ephemeral=True)
            return
        until = discord.utils.utcnow() + discord.timedelta(seconds=seconds)
        await member.timeout(until, reason=reason)
        await interaction.response.send_message(f"🔇 Timed out {member.mention} for {duration}.", ephemeral=True)

    @group.command(name="purge", description="Bulk delete messages")
    @app_commands.default_permissions(manage_messages=True)
    async def purge(self, interaction: discord.Interaction, amount: int):
        await interaction.response.defer(ephemeral=True, thinking=True)
        deleted = await interaction.channel.purge(limit=amount)
        await interaction.followup.send(f"🧹 Deleted {len(deleted)} messages.", ephemeral=True)

    @group.command(name="slowmode", description="Set channel slowmode (seconds, 0 to disable)")
    @app_commands.default_permissions(manage_channels=True)
    async def slowmode(self, interaction: discord.Interaction, seconds: int):
        await interaction.channel.edit(slowmode_delay=seconds)
        await interaction.response.send_message(f"🐢 Slowmode set to {seconds}s.", ephemeral=True)

    @group.command(name="lockdown", description="Toggle lockdown in this channel")
    @app_commands.default_permissions(manage_channels=True)
    async def lockdown(self, interaction: discord.Interaction, enable: bool):
        overwrite = interaction.channel.overwrites_for(interaction.guild.default_role)
        overwrite.send_messages = None if not enable else False
        await interaction.channel.set_permissions(interaction.guild.default_role, overwrite=overwrite)
        await interaction.response.send_message(f"{'🔒' if enable else '🔓'} Lockdown {'enabled' if enable else 'disabled'}.", ephemeral=True)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if not message.guild or message.author.bot:
            return
        settings = await get_guild_settings(message.guild.id)
        if settings.get("anti_invite", 1) and INVITE_RE.search(message.content):
            try:
                await message.delete()
                await message.channel.send(f"🚫 No invite links here, {message.author.mention}.", delete_after=5)
            except discord.Forbidden:
                pass
        max_mentions = settings.get("max_mentions", 5) or 0
        if max_mentions and len(message.mentions) > max_mentions:
            try:
                await message.delete()
                await message.channel.send(f"🚫 Too many mentions (>{max_mentions}), {message.author.mention}.", delete_after=5)
            except discord.Forbidden:
                pass
        banned = (settings.get("banned_words") or "").split(",")
        for w in banned:
            w = w.strip().lower()
            if not w: continue
            if w in message.content.lower():
                try:
                    await message.delete()
                    await message.channel.send(f"🚫 That word is not allowed here, {message.author.mention}.", delete_after=5)
                except discord.Forbidden:
                    pass

async def setup(bot: commands.Bot):
    await bot.add_cog(Moderation(bot))
