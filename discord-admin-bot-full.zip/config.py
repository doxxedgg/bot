import os
from dotenv import load_dotenv
load_dotenv()
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
APPLICATION_ID = os.getenv("APPLICATION_ID")
GUILD_ID = os.getenv("GUILD_ID")
if not DISCORD_TOKEN:
    raise RuntimeError("Missing DISCORD_TOKEN in environment")
