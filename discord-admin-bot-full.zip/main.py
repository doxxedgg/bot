import asyncio
import logging
import os
from typing import Optional

import discord
from discord.ext import commands

from config import DISCORD_TOKEN, GUILD_ID, APPLICATION_ID
from db import init_db

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("bot")

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.guilds = True
intents.reactions = True

class AdminBot(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix=commands.when_mentioned_or("!"),
            intents=intents,
            application_id=int(APPLICATION_ID) if APPLICATION_ID else None
        )
        self.synced = False

    async def setup_hook(self):
        # Load cogs
        for ext in (
            "cogs.utility",
            "cogs.admin",
            "cogs.moderation",
            "cogs.logging_cog",
            "cogs.welcome",
            "cogs.tickets",
            "cogs.roles",
        ):
            try:
                await self.load_extension(ext)
                logger.info("Loaded extension %s", ext)
            except Exception as e:
                logger.exception("Failed to load %s: %s", ext, e)

        # Sync commands
        await self.sync_commands()

    async def sync_commands(self):
        try:
            if GUILD_ID:
                guild_obj = discord.Object(id=int(GUILD_ID))
                self.tree.copy_global_to(guild=guild_obj)
                await self.tree.sync(guild=guild_obj)
                logger.info("Synced commands to guild %s", GUILD_ID)
            else:
                await self.tree.sync()
                logger.info("Synced global commands")
        except Exception:
            logger.exception("Failed to sync commands")

bot = AdminBot()

@bot.event
async def on_ready():
    await init_db()
    logger.info("Logged in as %s (%s)", bot.user, bot.user.id if bot.user else "?")
    await bot.change_presence(activity=discord.Game(name="/help • admin bot"))

if __name__ == "__main__":
    if os.name != "nt":
        try:
            import uvloop
            uvloop.install()
        except Exception:
            pass
    bot.run(DISCORD_TOKEN)
