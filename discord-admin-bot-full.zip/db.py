import aiosqlite

DB_PATH = "data.sqlite3"

SCHEMA = """CREATE TABLE IF NOT EXISTS guild_settings (
    guild_id INTEGER PRIMARY KEY,
    log_channel_id INTEGER,
    welcome_channel_id INTEGER,
    welcome_message TEXT,
    leave_message TEXT,
    ticket_category_id INTEGER,
    anti_invite INTEGER DEFAULT 1,
    max_mentions INTEGER DEFAULT 5,
    banned_words TEXT DEFAULT ''
);
"""

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(SCHEMA)
        await db.commit()

async def get_guild_settings(guild_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM guild_settings WHERE guild_id = ?", (guild_id,))
        row = await cur.fetchone()
        if row is None:
            await db.execute("INSERT INTO guild_settings (guild_id) VALUES (?)", (guild_id,))
            await db.commit()
            return await get_guild_settings(guild_id)
        return dict(row)

async def set_guild_setting(guild_id: int, key: str, value):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(f"UPDATE guild_settings SET {key} = ? WHERE guild_id = ?", (value, guild_id))
        await db.commit()
