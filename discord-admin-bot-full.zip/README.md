# Discord Admin Bot (Python)

This repo contains a Discord admin bot.
