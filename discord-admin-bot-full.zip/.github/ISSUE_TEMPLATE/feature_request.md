Feature request template
