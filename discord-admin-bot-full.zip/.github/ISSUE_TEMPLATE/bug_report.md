Bug report template
